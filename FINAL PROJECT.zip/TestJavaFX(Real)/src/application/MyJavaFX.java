package application;
	

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MyJavaFX extends Application   {

	
	//calling items
	Stage window; 
	Scene mainScene, sceneCorn, sceneBeans;
	
	
	GridPane cornPane = new GridPane();
	GridPane beanPane = new GridPane();
	@Override
	public void start(Stage primaryStage) throws Exception {
		
		window = primaryStage;
		
		
		Label label1 = new Label("Welcome! Select either corn or beans to get started.");
		Button cornBtn = new Button("Corn");
		Button beansBtn = new Button("Beans");
		cornBtn.setOnAction(e-> window.setScene(sceneCorn));
		beansBtn.setOnAction(e-> window.setScene(sceneBeans));
		
		//Layout 1- children are laid out in vertical column
		VBox layout1 = new VBox(25);
		layout1.getChildren().addAll(label1, cornBtn, beansBtn);
		mainScene = new Scene(layout1, 500, 200);
		
		
		/*EVERYTHING BEYOND THIS POINT IS FOR THE CORN WINDOW*/
		
		Button returnBtn1 = new Button("go back to main menu(From Corn)");
		returnBtn1.setOnAction(e-> window.setScene(mainScene));
		
		Button submitBtn = new Button("Calculate Price");
		Button resetBtn = new Button("Reset bags");
	

		
		//text field and label for Corn Selection
		Label finalLabel = new Label();
		TextField textfield = new TextField();
		textfield.setMaxWidth(70);
		textfield.setPromptText("Enter a number");
		TextField textfield2 = new TextField();
		textfield2.setMaxWidth(70);
		TextField textfield3 = new TextField();
		textfield3.setMaxWidth(70);
		
		
		//Layout for corn selection
		cornPane.setHgap(1);
		cornPane.setVgap(10);
		HBox cornHBOX= new HBox(10);
		
		//Labels
		Label cornLabel = new Label("You selected: Corn");
		Label hybridALabel = new Label ("Hybrid A ($15/bag):");
		Label hybridALabel2 = new Label ("Hybrid B ($19/bag):");
		Label hybridALabel3 = new Label ("Hybrid C ($11/bag):");
		Label attention = new Label ("Enter only positive numbers, please.");
		
		//Formatting
		cornHBOX.getChildren().addAll(hybridALabel,cornLabel, textfield, textfield2, textfield3,returnBtn1, hybridALabel2, hybridALabel3,submitBtn,finalLabel, attention);
		cornPane.add(cornLabel, 0, 0);
		cornPane.add(textfield, 1, 1);
		cornPane.add(textfield2, 1, 2);
		cornPane.add(textfield3, 1, 3);
		cornPane.add(returnBtn1, 0, 8);
		cornPane.add(hybridALabel, 0, 1);
		cornPane.add(hybridALabel2, 0, 2);
		cornPane.add(hybridALabel3, 0, 3);
		cornPane.add(submitBtn, 0, 5);
		cornPane.add(finalLabel, 1,5 );
		cornPane.add(resetBtn, 0, 6);
		cornPane.add(attention, 1, 6);
		//create scene
		cornHBOX.getChildren().addAll();
		cornPane.setPadding(new Insets(10)); 
		sceneCorn= new Scene(cornPane, 600, 300);
		
		
		window.setScene(mainScene);
		window.setTitle("Bryce's Seed Sales");
		
		
		window.show();
		textfield.setText("0");
		textfield2.setText("0");
		textfield3.setText("0");
		
		
		submitBtn.setOnAction(e->{
		textfield.setText(textfield.getText());
		
		double doubleFinal = 0.0;
		double doublePrice = Double.parseDouble(textfield.getText());
		double doublePrice2 = Double.parseDouble(textfield2.getText());
		double doublePrice3 = Double.parseDouble(textfield3.getText());
		doubleFinal = (doublePrice * 15 ); 
		doubleFinal = doubleFinal +  (doublePrice2 * 19); 
		doubleFinal =  doubleFinal + (doublePrice3 * 11) ; 
		
		
		String stringPrice = (Double.toString(doubleFinal));
		finalLabel.setText("Your Total Price is: $" + stringPrice + ". Have a nice day.");
		});
		
		
		//Button that resets the price
		resetBtn.setOnAction(e->{
			textfield.setText("0");
			textfield2.setText("0");
			textfield3.setText("0");
			});
		
		/*THIS CONCLUDES THE CORN WINDOW*/
		
		/* EVERYTHING BEYOND THIS POINT IS FOR THE BEANS WINDOW */
		
		
		// buttons for beans selection
		Button returnBtn2 = new Button("Go back to main menu(From Beans)");
		returnBtn2.setOnAction(e->window.setScene(mainScene));
		
		Button submitBtn2 = new Button("Calculate Price");
		Button resetBtn2 = new Button("Reset bags");
	

		
		//text field and label for bean Selection
		Label finalLabel2 = new Label();
		TextField textfield11 = new TextField();
		textfield11.setMaxWidth(70);
		textfield11.setPromptText("Enter a number");
		TextField textfield22 = new TextField();
		textfield22.setMaxWidth(70);
		TextField textfield33 = new TextField();
		textfield33.setMaxWidth(70);
		
		//Layout for bean selection
		beanPane.setHgap(1);
		beanPane.setVgap(10);
		HBox beanHBOX= new HBox(10);
		
		//Labels
		Label beanLabel = new Label("You selected: Beans");
		Label bhybridALabel = new Label ("Hybrid A ($22/bag):");
		Label bhybridALabel2 = new Label ("Hybrid B ($27/bag):");
		Label bhybridALabel3 = new Label ("Hybrid C ($34/bag):");
		Label attention2 = new Label ("Enter only positive numbers, please.");
		
		//Formatting
		beanHBOX.getChildren().addAll(finalLabel2, beanLabel, bhybridALabel, bhybridALabel2, bhybridALabel3, textfield11, textfield22, textfield33, submitBtn2, resetBtn2, attention2 );
		beanPane.add(beanLabel, 0, 0);
		beanPane.add(textfield11, 1, 1);
		beanPane.add(textfield22, 1, 2);
		beanPane.add(textfield33, 1, 3);
		beanPane.add(returnBtn2, 0, 8);
		beanPane.add(bhybridALabel, 0, 1);
		beanPane.add(bhybridALabel2, 0, 2);
		beanPane.add(bhybridALabel3, 0, 3);
		beanPane.add(submitBtn2, 0, 5);
		beanPane.add(finalLabel2, 1,5 );
		beanPane.add(resetBtn2, 0, 6);
		beanPane.add(attention2, 1, 6);
		
		//create scene
		beanHBOX.getChildren().addAll();
		beanPane.setPadding(new Insets(10)); 
		sceneBeans= new Scene(beanPane, 600, 300);
		
		//initially set the text fields
		textfield11.setText("0");
		textfield22.setText("0");
		textfield33.setText("0");
		
		
		submitBtn2.setOnAction(e->{
			textfield11.setText(textfield11.getText());
			
			double doubleFinal1 = 0.0;
			double doublePrice1 = Double.parseDouble(textfield11.getText());
			double doublePrice22 = Double.parseDouble(textfield22.getText());
			double doublePrice33 = Double.parseDouble(textfield33.getText());
			doubleFinal1 = (doublePrice1 * 22 ); 
			doubleFinal1 = doubleFinal1 +  (doublePrice22 * 27); 
			doubleFinal1 =  doubleFinal1 + (doublePrice33 * 34) ; 
			
			
			String stringPrice2 = (Double.toString(doubleFinal1));
			finalLabel2.setText("Your Total Price is: $" + stringPrice2 + ". Have a nice day.");
			});
			
			
			//Button that resets the price
			resetBtn2.setOnAction(e->{
				textfield11.setText("0");
				textfield22.setText("0");
				textfield33.setText("0");
				});
		
			/*THIS CONCLUDES THE BEAN WINDOW*/
		
	}
}