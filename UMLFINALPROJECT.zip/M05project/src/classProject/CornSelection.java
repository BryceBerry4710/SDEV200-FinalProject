package classProject;

public class CornSelection extends MainProject {
	// call doublePrices
	private double doublePrice;
	private double doublePrice2;
	private double doublePrice3;
	
	public CornSelection() {
		
	}
	
	public CornSelection (double doublePrice , double doublePrice2, double doublePrice3) {
		
	}
	//return doublePrices

		public double getdoublePrice() {
			return doublePrice;
	}

	public double getdoublePrice2() {
		return doublePrice2;
	}
	public double getdoublePrice3() {
		return doublePrice3;
	}
	
}
