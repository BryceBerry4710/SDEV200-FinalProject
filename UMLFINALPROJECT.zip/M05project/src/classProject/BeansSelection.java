package classProject;

public class BeansSelection extends MainProject {
	
	// call doublePrices
	private double doublePrice11;
	private double doublePrice22;
	private double doublePrice33;
	public void BeanSelection() {
		
	}
	public void BeanSelection(double doublePrice11, double doublePrice22, double doublePrice33) {
		
	}
	
	//return doublePrices
		public double getdoublePrice11() {
			return doublePrice11;
	}
		public double getdoublePrice22() {
			return doublePrice22;
		}
		public double getdoublePrice33() {
			return doublePrice33;
		}
		
		
	}
