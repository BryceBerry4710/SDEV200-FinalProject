package classProject;


public class MainProject {
	
	
	
	
//calling in all variables
	private static double doublePrice;
	private static double doublePrice2;
	private static double doublePrice3;
	private static double doublePrice11;
	private static double doublePrice22;
	private static double doublePrice33;
	private static String stringPrice;
	
	
		
		
		// set doublePrice on main
		public MainProject() {
			
		}
		
		public void setdoublePrice() {
			
		}
		public void setdoublePrice2() {
			
		}
		public void setdoublePrice3() {
			
		}
		public void setdoublePrice11() {
			
			
		}
		public void setdoublePrice22() {
		}
			public void setdoublePrice33() {
				
			}
}


